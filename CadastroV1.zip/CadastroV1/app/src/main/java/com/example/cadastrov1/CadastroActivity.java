package com.example.cadastrov1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CadastroActivity extends AppCompatActivity {

   TextView txtNome;
   TextView txtEmail;
   TextView txtFone;
   TextView txtEndereco;
   Button   btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        txtNome     = findViewById(R.id.txtNome);
        txtEmail    = findViewById(R.id.txtEmail);
        txtFone     = findViewById(R.id.txtFone);
        txtEndereco = findViewById(R.id.txtEndereco);
        btnVoltar   = findViewById(R.id.btnVoltar);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        String nome     = bundle.getString("nome", "");
        String email    = bundle.getString("email","");
        String fone     = bundle.getString("fone", "");
        String endereco = bundle.getString("endereco", "");

        txtNome.setText("Nome: " + nome);
        txtEmail.setText("E-mail: " + email);
        txtFone.setText("Telefone: " + fone);
        txtEndereco.setText("Endereço: " + endereco);


        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(CadastroActivity.this, MainActivity.class));

            }
        });


    }
}
