package com.example.aluno.pagamento;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class PagamentoActivity extends AppCompatActivity {

    TextView txtNome;
    TextView txtValHora;
    TextView txtHorasTrab;
    TextView txtSalBrut;
    TextView txtIR;
    TextView txtINSS;
    TextView txtFGTS;
    TextView txtSalLiq;
    Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagamento);

        txtNome = findViewById(R.id.txtNome);
        txtValHora = findViewById(R.id.txtValHora);
        txtHorasTrab = findViewById(R.id.txtHorasTrab);
        txtSalBrut = findViewById(R.id.txtSalBrut);
        txtIR = findViewById(R.id.txtIR);
        txtINSS = findViewById(R.id.txtINSS);
        txtFGTS = findViewById(R.id.txtFGTS);
        txtSalLiq = findViewById(R.id.txtSalLiq);
        btnVoltar = findViewById(R.id.btnVoltar);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        String nome = bundle.getString("nome","");
        Float horas = bundle.getFloat("horas");
        Float valor = bundle.getFloat("valor");

        float salbrut = horas*valor;
        double ir = Double.valueOf(0);
        double inss = Double.valueOf(0);
        float fgts = (8/100)*salbrut;
        double salliq = salbrut-ir-inss;

        if (salbrut<=1372.81){
            ir = Double.valueOf(0);
        }else if(salbrut<=2743.25){
            ir = Double.valueOf(0.15)*salbrut;
        }else {
            ir = (0.275)*salbrut;
        }

        if (salbrut<=868.29){
            inss = Double.valueOf (0.08)*salbrut;
        }else if (salbrut<=1447.14){
            inss = Double.valueOf(0.09)* salbrut;
        }else if (salbrut<=2894.28){
            inss = Double.valueOf(0.11)*salbrut;
        }else {
            inss = 318.37;
        }


        txtNome.setText("Nome: " + nome);
        txtValHora.setText("Valor da hora: " + valor);
        txtHorasTrab.setText("Horas trabalhadas: " + horas);
        txtSalBrut.setText("Salario bruto: " + salbrut);
        txtIR.setText("IR: " + ir);
        txtINSS.setText("INSS: " + inss);
        txtFGTS.setText("FGTS: " + fgts);
        txtSalLiq.setText("Salario liquido: " + salliq);

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(PagamentoActivity.this, MainActivity.class));
            }
        });

    }
}
