package com.example.aluno.pagamento;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edtNome;
    EditText edtHoras;
    EditText edtValor;
    Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNome = findViewById(R.id.edtNome);
        edtHoras = findViewById(R.id.edtHoras);
        edtValor = findViewById(R.id.edtValor);
        btnCalcular = findViewById(R.id.btnCalcular);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(edtNome.getText().toString().isEmpty()||
                        edtHoras.getText().toString().isEmpty()||
                        edtValor.getText().toString().isEmpty()){

                    Toast.makeText(MainActivity.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                }else{

                    String nome = edtNome.getText().toString();
                    float horas = Float.parseFloat(edtHoras.getText().toString());
                    float valor = Float.parseFloat(edtValor.getText().toString());

                    Bundle bundle = new Bundle();
                    bundle.putString("nome",nome);
                    bundle.putFloat("horas",horas);
                    bundle.putFloat("valor",valor);

                    Intent intent = new Intent(MainActivity.this, PagamentoActivity.class);
                    intent.putExtras(bundle);

                    startActivity(intent);

                }

            }
        });

    }
}
